# Android ilova qismi

Keyingi bosqichda Kotlin + Jetpack Compose UI, Room lokal bazasi, Retrofit API va WorkManager sync worker to‘liq implementatsiya qilinadi. Backend API hozir alohida ishlaydi. Android moduli ataylab hozircha to‘liq bo‘lmagan holda qoldirilgan — ishlamaydigan demo APK deb ko‘rsatmaslik uchun.
