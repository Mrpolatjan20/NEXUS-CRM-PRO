# NEXUS CRM PRO

Maqsad: Android uchun qulay CRM, FastAPI + PostgreSQL backend, offline-first sinxronizatsiya.

## Arxitektura
- Android: Kotlin, Jetpack Compose, Room (lokal kesh), WorkManager (fon sinxronizatsiya), Retrofit.
- Backend: FastAPI, PostgreSQL, JWT, rollar, audit jurnali.
- Rollar: operator, manager, admin.
- Asosiy modullar: mijozlar, arizalar, xodimlar, KPI/hisobotlar, fayllar, bildirishnomalar.

## Muhim holat
Bu birinchi texnik asos. Hali production uchun tayyor emas: kamera oqimi, to‘liq Room DAO/Worker, server migratsiyalari, chat, push, hisobotlar, HTTPS deploy va xavfsizlik auditi keyingi bosqichlarda bajariladi. Haqiqiy pasport/JSHSHIR ma’lumotlarini xavfsizlik tekshiruvidan oldin kiritmang.

## Backendni ishga tushirish
1. Python 3.11+ o‘rnating.
2. `backend` ichida `pip install -r requirements.txt`.
3. `DATABASE_URL` va `JWT_SECRET` muhit o‘zgaruvchilarini belgilang.
4. `uvicorn app.main:app --reload`.
5. API: `/docs`.
