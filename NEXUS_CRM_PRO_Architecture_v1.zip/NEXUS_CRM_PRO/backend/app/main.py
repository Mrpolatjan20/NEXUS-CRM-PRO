from datetime import datetime, timedelta, timezone
import os, uuid
import jwt
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, DateTime, Boolean, ForeignKey, select, or_
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session
from sqlalchemy.exc import IntegrityError
from pwdlib import PasswordHash

DB_URL = os.getenv('DATABASE_URL', 'sqlite:///./nexus_dev.db')
JWT_SECRET = os.getenv('JWT_SECRET', 'DEV_ONLY_CHANGE_THIS_SECRET_32_CHARS')
engine = create_engine(DB_URL, connect_args={'check_same_thread': False} if DB_URL.startswith('sqlite') else {}, pool_pre_ping=True)
SessionLocal = sessionmaker(engine, autoflush=False, autocommit=False)
passwords = PasswordHash.recommended()
bearer = OAuth2PasswordBearer(tokenUrl='/auth/login')

class Base(DeclarativeBase): pass
class Employee(Base):
    __tablename__='employees'
    id: Mapped[str]=mapped_column(String(36), primary_key=True, default=lambda:str(uuid.uuid4()))
    username: Mapped[str]=mapped_column(String(80), unique=True, index=True)
    full_name: Mapped[str]=mapped_column(String(160))
    password_hash: Mapped[str]=mapped_column(String(255))
    role: Mapped[str]=mapped_column(String(20), default='operator')
    is_active: Mapped[bool]=mapped_column(Boolean, default=True)
class Customer(Base):
    __tablename__='customers'
    id: Mapped[str]=mapped_column(String(36), primary_key=True, default=lambda:str(uuid.uuid4()))
    full_name: Mapped[str]=mapped_column(String(180), index=True)
    passport_number: Mapped[str]=mapped_column(String(32), unique=True)
    pinfl: Mapped[str]=mapped_column(String(14), unique=True)
    phone: Mapped[str|None]=mapped_column(String(32), nullable=True)
    address: Mapped[str|None]=mapped_column(String(500), nullable=True)
    created_by: Mapped[str]=mapped_column(ForeignKey('employees.id'))
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=lambda:datetime.now(timezone.utc), onupdate=lambda:datetime.now(timezone.utc))
class Application(Base):
    __tablename__='applications'
    id: Mapped[str]=mapped_column(String(36), primary_key=True, default=lambda:str(uuid.uuid4()))
    customer_id: Mapped[str]=mapped_column(ForeignKey('customers.id'), index=True)
    title: Mapped[str]=mapped_column(String(180))
    status: Mapped[str]=mapped_column(String(20), default='pending', index=True)
    created_by: Mapped[str]=mapped_column(ForeignKey('employees.id'))
    reviewed_by: Mapped[str|None]=mapped_column(ForeignKey('employees.id'), nullable=True)
    review_note: Mapped[str|None]=mapped_column(String(1000), nullable=True)
class AuditLog(Base):
    __tablename__='audit_logs'
    id: Mapped[str]=mapped_column(String(36), primary_key=True, default=lambda:str(uuid.uuid4()))
    actor_id: Mapped[str]=mapped_column(String(36), index=True)
    action: Mapped[str]=mapped_column(String(80))
    entity_id: Mapped[str]=mapped_column(String(36))
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=lambda:datetime.now(timezone.utc))

class Login(BaseModel): username:str; password:str
class EmployeeIn(BaseModel): username:str=Field(min_length=3); full_name:str; password:str=Field(min_length=12); role:str='operator'
class CustomerIn(BaseModel): full_name:str=Field(min_length=3); passport_number:str; pinfl:str=Field(pattern=r'^\d{14}$'); phone:str|None=None; address:str|None=None
class ApplicationIn(BaseModel): customer_id:str; title:str
class ReviewIn(BaseModel): status:str=Field(pattern='^(approved|rejected)$'); note:str|None=None

app=FastAPI(title='NEXUS CRM API', version='0.1.0')
Base.metadata.create_all(engine)
def db_session():
    db=SessionLocal()
    try: yield db
    finally: db.close()
def user_from_token(token:str=Depends(bearer), db:Session=Depends(db_session)):
    try:
        data=jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        user=db.get(Employee, data['sub'])
        if not user or not user.is_active: raise ValueError()
        return user
    except Exception: raise HTTPException(401, 'Token yaroqsiz yoki muddati tugagan')
def roles(*allowed):
    def check(user=Depends(user_from_token)):
        if user.role not in allowed: raise HTTPException(403, 'Ruxsat yo‘q')
        return user
    return check
@app.get('/health')
def health(): return {'status':'ok','service':'nexus-crm-api'}
@app.post('/auth/login')
def login(data:Login, db:Session=Depends(db_session)):
    u=db.scalar(select(Employee).where(Employee.username==data.username))
    if not u or not u.is_active or not passwords.verify(data.password,u.password_hash): raise HTTPException(401,'Login yoki parol xato')
    now=datetime.now(timezone.utc)
    token=jwt.encode({'sub':u.id,'role':u.role,'iat':now,'exp':now+timedelta(minutes=30)},JWT_SECRET,algorithm='HS256')
    return {'access_token':token,'token_type':'bearer','expires_in':1800,'role':u.role}
@app.post('/employees',status_code=201)
def add_employee(data:EmployeeIn, db:Session=Depends(db_session), admin=Depends(roles('admin'))):
    if data.role not in ('operator','manager','admin'): raise HTTPException(422,'Noto‘g‘ri rol')
    u=Employee(username=data.username,full_name=data.full_name,password_hash=passwords.hash(data.password),role=data.role)
    db.add(u)
    try: db.flush(); db.add(AuditLog(actor_id=admin.id,action='employee.created',entity_id=u.id)); db.commit()
    except IntegrityError: db.rollback(); raise HTTPException(409,'Login band')
    return {'id':u.id,'username':u.username,'role':u.role}
@app.post('/customers',status_code=201)
def add_customer(data:CustomerIn, db:Session=Depends(db_session), user=Depends(roles('operator','manager','admin'))):
    c=Customer(**data.model_dump(),created_by=user.id); db.add(c)
    try: db.flush(); db.add(AuditLog(actor_id=user.id,action='customer.created',entity_id=c.id)); db.commit()
    except IntegrityError: db.rollback(); raise HTTPException(409,'Pasport yoki JSHSHIR avval kiritilgan')
    return {'id':c.id,'full_name':c.full_name}
@app.get('/customers')
def customers(q:str|None=None, limit:int=Query(30,ge=1,le=100), offset:int=Query(0,ge=0), db:Session=Depends(db_session), user=Depends(user_from_token)):
    stmt=select(Customer)
    if q:
        term=f'%{q.strip()}%'; stmt=stmt.where(or_(Customer.full_name.ilike(term),Customer.passport_number.ilike(term),Customer.pinfl.ilike(term),Customer.phone.ilike(term)))
    rows=db.scalars(stmt.order_by(Customer.updated_at.desc()).limit(limit).offset(offset)).all()
    return {'items':[{'id':x.id,'full_name':x.full_name,'passport_number':x.passport_number,'pinfl':x.pinfl,'phone':x.phone,'address':x.address,'updated_at':x.updated_at} for x in rows], 'limit':limit,'offset':offset}
@app.post('/applications',status_code=201)
def add_application(data:ApplicationIn, db:Session=Depends(db_session), user=Depends(user_from_token)):
    if not db.get(Customer,data.customer_id): raise HTTPException(404,'Mijoz topilmadi')
    a=Application(**data.model_dump(),created_by=user.id); db.add(a); db.flush(); db.add(AuditLog(actor_id=user.id,action='application.created',entity_id=a.id)); db.commit()
    return {'id':a.id,'status':a.status}
@app.get('/applications')
def applications(status:str|None=None, limit:int=Query(30,ge=1,le=100), offset:int=Query(0,ge=0), db:Session=Depends(db_session), user=Depends(user_from_token)):
    stmt=select(Application)
    if status: stmt=stmt.where(Application.status==status)
    rows=db.scalars(stmt.order_by(Application.id.desc()).limit(limit).offset(offset)).all()
    return {'items':[{'id':a.id,'customer_id':a.customer_id,'title':a.title,'status':a.status} for a in rows]}
@app.patch('/applications/{app_id}/review')
def review(app_id:str, data:ReviewIn, db:Session=Depends(db_session), user=Depends(roles('manager','admin'))):
    a=db.get(Application,app_id)
    if not a: raise HTTPException(404,'Ariza topilmadi')
    if a.status!='pending': raise HTTPException(409,'Ariza oldin ko‘rib chiqilgan')
    a.status=data.status; a.review_note=data.note; a.reviewed_by=user.id
    db.add(AuditLog(actor_id=user.id,action='application.'+data.status,entity_id=a.id)); db.commit()
    return {'id':a.id,'status':a.status}
